const express = require('express')
const router = express.Router()


let isLogin = false

router.get('/', (req, res) => {
    res.render('game')
})

router.get('/login', (req, res) => {
    res.render('login')
})

router.post('/login', (req, res) => {
    const {
        username,
        password
    } = req.body
})

router.get('/register', (req, res) => {
    res.render('register')
})

router.post('/register', (req, res) => {
    const {
        username,
        password
    } = req.body

    const id = posts[posts.length - 1].id + 1

    const user = {
        id,
        username,
        password
    }
})

module.exports = router